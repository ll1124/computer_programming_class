#include<stdio.h>

int main(void) {

  int num = 0;
  printf("number square cube\n");
  printf("%d\t%d\t%d\n", num, num*num, num*num*num); // 0
  printf("%d\t%d\t%d\n", num + 1, (num + 1)*(num + 1), (num + 1)*(num + 1)*(num + 1)); // 1
  printf("%d\t%d\t%d\n", num + 2, (num + 2)*(num + 2), (num + 2)*(num + 2)*(num + 2)); // 2
  printf("%d\t%d\t%d\n", num + 3, (num + 3)*(num + 3), (num + 3)*(num + 3)*(num + 3)); // 3
  printf("%d\t%d\t%d\n", num + 4, (num + 4)*(num + 4), (num + 4)*(num + 4)*(num + 4)); // 4
  printf("%d\t%d\t%d\n", num + 5, (num + 5)*(num + 5), (num + 5)*(num + 5)*(num + 5)); // 5
  printf("%d\t%d\t%d\n", num + 6, (num + 6)*(num + 6), (num + 6)*(num + 6)*(num + 6)); // 6
  printf("%d\t%d\t%d\n", num + 7, (num + 7)*(num + 7), (num + 7)*(num + 7)*(num + 7)); // 7
  printf("%d\t%d\t%d\n", num + 8, (num + 8)*(num + 8), (num + 8)*(num + 8)*(num + 8)); // 8
  printf("%d\t%d\t%d\n", num + 9, (num + 9)*(num + 9), (num + 9)*(num + 9)*(num + 9)); // 9
  printf("%d\t%d\t%d\n", num + 10, (num + 10)*(num + 10), (num + 10)*(num + 10)*(num + 10)); // 10

  return 0;
  }
